function applyTheme() {
    document.body.classList.toggle('dark-mode', localStorage.getItem('muzakara-theme') === 'dark');
}

applyTheme();

window.toggleTheme = () => {
    const dark = localStorage.getItem('muzakara-theme') !== 'dark';
    localStorage.setItem('muzakara-theme', dark ? 'dark' : 'light');
    applyTheme();
};