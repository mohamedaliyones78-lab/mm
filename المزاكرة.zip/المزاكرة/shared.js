const subjectDefaults = [
    { name: 'عربي', icon: 'ع', color: '#d77b6e' },
    { name: 'إنجليزي', icon: 'En', color: '#82b7a2' },
    { name: 'تاريخ', icon: 'ت', color: '#f1a65b' },
    { name: 'برمجة', icon: '</>', color: '#8c9ed8' },
];

const subjectColors = subjectDefaults.map((subject) => subject.color);

function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>'"]/g, (character) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        "'": '&#39;',
        '"': '&quot;',
    }[character]));
}

function weekKey(date = new Date()) {
    const monday = new Date(date);
    const day = monday.getDay() || 7;
    monday.setDate(monday.getDate() - day + 1);
    monday.setHours(0, 0, 0, 0);
    return monday.toISOString().slice(0, 10);
}

function readSubjects() {
    return JSON.parse(localStorage.getItem('muzakara-subjects') || 'null');
}

function getSubjects() {
    const saved = readSubjects();
    const savedSubjects = saved?.subjects || [];
    const currentWeek = weekKey();
    const isNewWeek = saved?.week !== currentWeek;
    const subjects = [...subjectDefaults, ...savedSubjects.filter((subject) => !subjectDefaults.some((base) => base.name === subject.name))].map((base, index) => {
        const savedSubject = savedSubjects.find((subject) => subject.name === base.name);
        const isDefault = subjectDefaults.some((defaultSubject) => defaultSubject.name === base.name);
        return {
            ...base,
            ...(savedSubject || {}),
            icon: isDefault ? base.icon : (savedSubject?.icon || base.icon),
            color: base.color || subjectColors[index % subjectColors.length],
            target: savedSubject?.target || 0,
            studied: isNewWeek ? 0 : (savedSubject?.studied || 0),
        };
    });
    if (!saved || isNewWeek) localStorage.setItem('muzakara-subjects', JSON.stringify({ week: currentWeek, subjects }));
    return subjects;
}

function saveSubjectsShared(subjects) {
    localStorage.setItem('muzakara-subjects', JSON.stringify({ week: weekKey(), subjects }));
}

function subjectIndex(subjectName, subjects) {
    return Math.max(0, subjects.findIndex((subject) => subject.name === subjectName));
}

function currentWeekSessions() {
    const start = weekKey();
    return JSON.parse(localStorage.getItem('muzakara-sessions') || '[]').filter((session) => session.week === start || (session.dateISO && weekKey(new Date(session.dateISO)) === start));
}

function sessionRecord(seconds, subject, date = new Date()) {
    return { seconds, subject, date: date.toLocaleDateString('ar-EG'), dateISO: date.toISOString(), week: weekKey(date), day: date.getDay() };
}
