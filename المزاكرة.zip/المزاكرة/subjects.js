let subjects = getSubjects();
const overview = document.querySelector('#subjects-overview');

function saveSubjects() {
    saveSubjectsShared(subjects);
}

function render() {
    overview.innerHTML = subjects.map((subject, index) => {
        const percent = subject.target ? Math.min(100, Math.round(subject.studied / subject.target * 100)) : 0;
        const tasks = JSON.parse(localStorage.getItem(`muzakara-subject-tasks-${subject.name}`) || '[]');
        const done = tasks.filter((task) => task.done).length;
        return `<article class="subject-overview-card"><div class="subject-overview-head"><div class="subject-icon subject-icon-${index % 4}">${escapeHtml(subject.icon)}</div><div><h2>${escapeHtml(subject.name)}</h2><p>${subject.target || 0} دقيقة مستهدفة هذا الأسبوع</p></div><strong>${percent}%</strong></div><div class="bar"><span style="width:${percent}%;background:${subject.color}"></span></div><div class="subject-overview-meta"><span>${Math.floor(subject.studied || 0)} دقيقة مذاكرة</span><span>${done} من ${tasks.length} مهام</span></div><div class="subject-overview-actions"><a class="add-button subject-open-link" href="./subject.html?name=${encodeURIComponent(subject.name)}">فتح المادة</a><button class="delete-subject" type="button" data-name="${escapeHtml(subject.name)}">حذف المادة</button></div></article>`;
    }).join('');
}

document.querySelector('#add-subject').addEventListener('click', async () => {
    const name = await openTextModal('إضافة مادة جديدة', 'اكتب اسم المادة:');
    if (!name || subjects.some((subject) => subject.name === name)) return;
    subjects.push({ name, icon: escapeHtml(name.slice(0, 2)), color: subjectColors[subjects.length % subjectColors.length], target: 0, studied: 0 });
    saveSubjects();
    render();
});

overview.addEventListener('click', (event) => {
    const button = event.target.closest('.delete-subject');
    if (!button) return;
    openConfirmModal(`هل تريد حذف مادة ${button.dataset.name}؟`).then((confirmed) => {
        if (!confirmed) return;
        subjects = subjects.filter((subject) => subject.name !== button.dataset.name);
        localStorage.removeItem(`muzakara-subject-tasks-${button.dataset.name}`);
        saveSubjects();
        render();
    });
});

document.querySelector('#theme-toggle').addEventListener('click', () => {
    window.toggleTheme();
    document.querySelector('#theme-toggle span').textContent = document.body.classList.contains('dark-mode') ? 'الوضع النهاري' : 'الوضع الليلي';
});

document.querySelector('#theme-toggle span').textContent = document.body.classList.contains('dark-mode') ? 'الوضع النهاري' : 'الوضع الليلي';
render();
