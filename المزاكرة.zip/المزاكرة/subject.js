const subjectName = new URLSearchParams(window.location.search).get('name') || 'المادة';
const subjects = getSubjects();
const savedSubject = subjects.find((item) => item.name === subjectName);
const subject = savedSubject || { name: subjectName, icon: 'م', target: 0, studied: 0 };
const taskKey = `muzakara-subject-tasks-${subjectName}`;
let tasks = JSON.parse(localStorage.getItem(taskKey) || '[]');

 document.querySelector('#subject-title').textContent = subject.name;
document.querySelector('#subject-page-icon').textContent = subject.icon;
document.querySelector('#subject-page-icon').classList.add(`subject-icon-${subjectIndex(subject.name, subjects) % 4}`);
document.querySelector('#subject-target').textContent = `${subject.target || 0} دقيقة`;

function render() {
    const percent = subject.target ? Math.min(100, Math.round(subject.studied / subject.target * 100)) : 0;
    document.querySelector('#subject-percent').textContent = `${percent}%`;
    document.querySelector('#subject-minutes').textContent = `${Math.floor(subject.studied || 0)} / ${subject.target || 0} دقيقة`;
    document.querySelector('#subject-bar').style.width = `${percent}%`;
    document.querySelector('#subject-task-list').innerHTML = tasks.length ? tasks.map((task, index) => `<div class="task ${task.done ? 'done' : ''}" data-index="${index}"><span class="check">${task.done ? '✓' : ''}</span><div class="task-copy"><strong></strong><span>${escapeHtml(subject.name)}</span></div><button class="delete-task" type="button" aria-label="حذف المهمة">×</button></div>`).join('') : '<p class="empty-state">لا توجد مهام لهذه المادة بعد.</p>';
    document.querySelectorAll('#subject-task-list .task strong').forEach((element, index) => { element.textContent = tasks[index].title; });
}

const taskForm = document.querySelector('#subject-task-form');
const taskInput = document.querySelector('#subject-task-input');

document.querySelector('#add-subject-task').addEventListener('click', () => {
    taskForm.classList.toggle('hidden');
    if (!taskForm.classList.contains('hidden')) taskInput.focus();
});

function saveSubjectTask() {
    const title = taskInput.value.trim();
    if (!title) return;
    tasks.push({ title, done: false });
    localStorage.setItem(taskKey, JSON.stringify(tasks));
    taskInput.value = '';
    taskForm.classList.add('hidden');
    render();
}

document.querySelector('#save-subject-task').addEventListener('click', saveSubjectTask);
taskInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') saveSubjectTask();
});

document.querySelector('#subject-task-list').addEventListener('click', (event) => {
    const taskElement = event.target.closest('.task');
    if (!taskElement) return;
    const index = Number(taskElement.dataset.index);
    if (event.target.closest('.delete-task')) {
        openConfirmModal('هل تريد حذف هذه المهمة؟').then((confirmed) => {
            if (!confirmed) return;
            tasks.splice(index, 1);
            localStorage.setItem(taskKey, JSON.stringify(tasks));
            render();
        });
        return;
    } else {
        tasks[index].done = !tasks[index].done;
    }
    localStorage.setItem(taskKey, JSON.stringify(tasks));
    render();
});

render();
