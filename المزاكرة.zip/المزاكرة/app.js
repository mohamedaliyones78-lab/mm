const taskList = document.querySelector('.task-list');
const timerButton = document.querySelector('.timer-button');
const timerText = document.querySelector('.timer strong');
const addButton = document.querySelector('#add-task-button');
const progressNumber = document.querySelector('.progress-number strong');
const progressBar = document.querySelector('.bar span');
const progressFooter = document.querySelector('.progress-footer span');
const finishButton = document.querySelector('.finish-button');
const subjectGrid = document.querySelector('.subject-grid');
const addSubjectMain = document.querySelector('#add-subject-main');
const subjectPicker = document.querySelector('#subject-picker');
const subjectMenu = document.querySelector('#subject-menu');
const themeToggleMain = document.querySelector('#theme-toggle-main');
const calendar = document.querySelector('#sidebar-calendar');

let seconds = 0;
let timerId = null;
let activeSubject = '';
const savedSession = JSON.parse(localStorage.getItem('muzakara-active-session') || 'null');
if (savedSession) {
    seconds = savedSession.seconds || 0;
    activeSubject = savedSession.activeSubject || '';
}
const sessionTotals = savedSession?.sessionTotals || {};

let calendarDate = new Date();
let selectedCalendarDate = null;
const arabicMonths = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
const arabicDays = ['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س'];

function renderCalendar() {
    const year = calendarDate.getFullYear();
    const month = calendarDate.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const today = new Date();
    let days = arabicDays.map((day) => `<span class="calendar-day-name">${day}</span>`).join('');
    for (let blank = 0; blank < firstDay; blank += 1) days += '<span></span>';
    for (let day = 1; day <= daysInMonth; day += 1) {
        const isToday = day === today.getDate() && month === today.getMonth() && year === today.getFullYear();
        const dateKey = new Date(year, month, day).toISOString().slice(0, 10);
        const isSelected = dateKey === selectedCalendarDate;
        days += `<button class="calendar-day ${isToday ? 'today' : ''} ${isSelected ? 'selected' : ''}" type="button" data-date="${dateKey}" aria-pressed="${isSelected}">${day}</button>`;
    }
    calendar.innerHTML = `<div class="calendar-heading"><button id="calendar-prev" type="button">‹</button><strong>${arabicMonths[month]} ${year}</strong><button id="calendar-next" type="button">›</button></div><div class="calendar-grid">${days}</div>`;
    calendar.querySelector('#calendar-prev').addEventListener('click', () => { calendarDate.setMonth(month - 1); renderCalendar(); });
    calendar.querySelector('#calendar-next').addEventListener('click', () => { calendarDate.setMonth(month + 1); renderCalendar(); });
    calendar.querySelectorAll('.calendar-day').forEach((button) => button.addEventListener('click', () => {
        selectedCalendarDate = button.dataset.date;
        renderCalendar();
    }));
}

renderCalendar();

const savedUser = JSON.parse(localStorage.getItem('muzakara-user') || '{"name":"محمد"}');
document.querySelector('#sidebar-profile-name').textContent = `أهلاً، ${savedUser.name || 'محمد'}`;

themeToggleMain.querySelector('span').textContent = document.body.classList.contains('dark-mode') ? 'نهار' : 'ليل';
themeToggleMain.addEventListener('click', () => {
    window.toggleTheme();
    themeToggleMain.querySelector('span').textContent = document.body.classList.contains('dark-mode') ? 'نهار' : 'ليل';
});

let subjects = getSubjects();

function saveSubjects() {
    saveSubjectsShared(subjects);
}

async function addSubject() {
    const name = await openTextModal('إضافة مادة جديدة', 'اكتب اسم المادة:');
    if (!name || subjects.some((subject) => subject.name === name)) return;
    subjects.push({ name, icon: escapeHtml(name.slice(0, 2)), color: subjectColors[subjects.length % subjectColors.length], target: 0, studied: 0 });
    saveSubjects();
    renderSubjects();
}

function renderSubjects() {
    subjectGrid.innerHTML = subjects.map((subject, index) => {
        const percent = subject.target ? Math.min(100, Math.round(subject.studied / subject.target * 100)) : 0;
        return `<div class="subject"><div class="subject-icon subject-icon-${index % 4}">${escapeHtml(subject.icon)}</div><div class="subject-info"><div><strong>${escapeHtml(subject.name)}</strong><span>${percent}%</span></div><div class="subject-bar"><i style="width:${percent}%;background:${subject.color}"></i></div><small>${Math.floor(subject.studied)} / ${subject.target || 0} دقيقة هذا الأسبوع</small><div class="subject-actions"><button class="subject-start" data-index="${index}">ابدأ</button><button class="subject-duration" data-index="${index}">تحديد المدة</button><a class="subject-details" href="./subject.html?name=${encodeURIComponent(subject.name)}">التفاصيل</a><button class="delete-subject-main" type="button" data-index="${index}" title="حذف المادة" aria-label="حذف المادة">×</button></div></div></div>`;
    }).join('');
    subjectMenu.innerHTML = subjects.map((subject, index) => `<button type="button" data-index="${index}">${escapeHtml(subject.icon)} ${escapeHtml(subject.name)}</button>`).join('');
}

function selectSubject(index) {
    activeSubject = subjects[index].name;
    subjectPicker.innerHTML = `◉ <span>${escapeHtml(activeSubject)}</span>`;
    document.querySelector('.focus-note').textContent = `الجلسة الحالية: ${activeSubject}`;
    subjectMenu.classList.remove('open');
    if (!timerId) timerButton.innerHTML = `ابدأ ${escapeHtml(activeSubject)} <span>▶</span>`;
}

async function setSubjectDuration(index) {
    const input = await openTextModal(`مدة ${subjects[index].name}`, 'اكتب عدد الدقائق لهذا الأسبوع.');
    const value = Number(input);
    if (!Number.isFinite(value) || value < 1) return;
    subjects[index].target = Math.round(value);
    saveSubjects();
    renderSubjects();
}

subjectGrid.addEventListener('click', (event) => {
    const button = event.target.closest('button');
    if (!button) return;
    const index = Number(button.dataset.index);
    if (button.classList.contains('delete-subject-main')) {
        openConfirmModal(`هل تريد حذف مادة ${subjects[index].name}؟`).then((confirmed) => {
            if (!confirmed) return;
            localStorage.removeItem(`muzakara-subject-tasks-${subjects[index].name}`);
            subjects.splice(index, 1);
            saveSubjects();
            renderSubjects();
        });
        return;
    }
    if (button.classList.contains('subject-duration')) setSubjectDuration(index);
    if (button.classList.contains('subject-start')) {
        selectSubject(index);
        timerButton.innerHTML = `ابدأ ${escapeHtml(activeSubject)} <span>▶</span>`;
    }
});

addSubjectMain.addEventListener('click', addSubject);

subjectPicker.addEventListener('click', () => subjectMenu.classList.toggle('open'));
subjectMenu.addEventListener('click', (event) => {
    const button = event.target.closest('button');
    if (button) selectSubject(Number(button.dataset.index));
});

function updateProgress() {
    const tasks = [...document.querySelectorAll('.task')];
    const completed = tasks.filter((task) => task.classList.contains('done')).length;
    const progress = tasks.length ? Math.round((completed / tasks.length) * 100) : 0;
    progressNumber.textContent = `${progress}%`;
    progressBar.style.width = `${progress}%`;
    progressFooter.textContent = `تم إنجاز ${completed} من ${tasks.length} مهام`;
    localStorage.setItem('muzakara-tasks', taskList.innerHTML);
    const dayTotals = Array.from({ length: 7 }, (_, day) => currentWeekSessions().filter((session) => session.day === day).reduce((total, session) => total + session.seconds, 0));
    const maxDay = Math.max(...dayTotals, 60);
    document.querySelectorAll('.mini-chart i').forEach((bar, index) => { bar.style.height = `${Math.max(8, dayTotals[index] / maxDay * 100)}%`; });
}

function showTime() {
    const minutes = String(Math.floor(seconds / 60)).padStart(2, '0');
    const remainingSeconds = String(seconds % 60).padStart(2, '0');
    timerText.textContent = `${minutes}:${remainingSeconds}`;
}

taskList.addEventListener('click', (event) => {
    const task = event.target.closest('.task');
    if (!task) return;
    if (event.target.closest('.delete-task')) {
            openConfirmModal('هل تريد حذف هذه المهمة؟').then((confirmed) => {
                if (confirmed) task.remove();
                updateProgress();
            });
        return;
    }
    task.classList.toggle('done');
    task.querySelector('.check').textContent = task.classList.contains('done') ? '✓' : '';
    updateProgress();
});

timerButton.addEventListener('click', () => {
    if (!timerId && !activeSubject) {
        subjectMenu.classList.add('open');
        return;
    }
    if (timerId) {
        clearInterval(timerId);
        timerId = null;
        timerButton.innerHTML = 'استمرار الجلسة <span>▶</span>';
        return;
    }

    timerButton.innerHTML = 'إيقاف مؤقت <span>Ⅱ</span>';
    timerId = setInterval(() => {
        seconds += 1;
        sessionTotals[activeSubject] = (sessionTotals[activeSubject] || 0) + 1;
        localStorage.setItem('muzakara-active-session', JSON.stringify({ seconds, activeSubject, sessionTotals }));
        if (activeSubject) {
            const subject = subjects.find((item) => item.name === activeSubject);
            if (subject) {
                subject.studied += 1 / 60;
                saveSubjects();
                renderSubjects();
            }
        }
        showTime();
    }, 1000);
});

finishButton.addEventListener('click', () => {
    if (timerId) clearInterval(timerId);
    const sessions = JSON.parse(localStorage.getItem('muzakara-sessions') || '[]');
    Object.entries(sessionTotals).forEach(([subject, subjectSeconds]) => {
        if (subjectSeconds > 0) sessions.push(sessionRecord(subjectSeconds, subject));
    });
    localStorage.setItem('muzakara-sessions', JSON.stringify(sessions));
    localStorage.removeItem('muzakara-active-session');
    window.location.href = './progress.html';
});

async function addTaskFromButton() {
    const title = await openTextModal('إضافة مهمة جديدة', 'اكتب اسم المهمة:');
    if (!title || !title.trim()) return;
    const task = document.createElement('div');
    task.className = 'task';
    task.innerHTML = `<span class="check"></span><div class="task-copy"><strong></strong><span>عام</span></div><span class="task-time">25 دقيقة</span><button class="delete-task" type="button" aria-label="حذف المهمة" title="حذف المهمة">×</button>`;
    task.querySelector('strong').textContent = title.trim();
    taskList.appendChild(task);
    updateProgress();
}

document.addEventListener('click', (event) => {
    if (event.target.closest('#add-task-button')) addTaskFromButton();
});

const savedTasks = localStorage.getItem('muzakara-tasks');
if (savedTasks) taskList.innerHTML = savedTasks;
document.querySelectorAll('.task').forEach((task) => {
    if (task.querySelector('.delete-task')) return;
    const deleteButton = document.createElement('button');
    deleteButton.className = 'delete-task';
    deleteButton.type = 'button';
    deleteButton.setAttribute('aria-label', 'حذف المهمة');
    deleteButton.title = 'حذف المهمة';
    deleteButton.textContent = '×';
    task.appendChild(deleteButton);
});
document.querySelector('#current-date').textContent = new Intl.DateTimeFormat('ar-EG', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date());
const weekSessionSeconds = currentWeekSessions().reduce((total, session) => total + session.seconds, 0);
document.querySelector('.trend').textContent = weekSessionSeconds ? `${Math.floor(weekSessionSeconds / 60)} دقيقة هذا الأسبوع` : 'ابدأ أول جلسة';
if (activeSubject) timerButton.innerHTML = `استمرار ${escapeHtml(activeSubject)} <span>▶</span>`;
showTime();
renderSubjects();
updateProgress();
