const sessions = JSON.parse(localStorage.getItem('muzakara-sessions') || '[]');
const weeklySessions = currentWeekSessions();
const subjectsData = getSubjects();
const savedTasks = localStorage.getItem('muzakara-tasks');
const taskContainer = document.createElement('div');
if (savedTasks) taskContainer.innerHTML = savedTasks;
const tasks = [...taskContainer.querySelectorAll('.task')];
const completed = tasks.filter((task) => task.classList.contains('done')).length;
const totalSeconds = sessions.reduce((total, session) => total + session.seconds, 0);
const formatTime = (value) => `${String(Math.floor(value / 60)).padStart(2, '0')}:${String(value % 60).padStart(2, '0')}`;
const user = JSON.parse(localStorage.getItem('muzakara-user') || '{"name":"محمد","phone":"","guardianPhone":""}');

document.querySelector('#user-name').value = user.name || '';
document.querySelector('#user-phone').value = user.phone || '';
document.querySelector('#guardian-phone').value = user.guardianPhone || '';
document.querySelector('#profile-name').textContent = user.name || 'محمد';
document.querySelector('#profile-heading').firstChild.textContent = `أهلاً، ${user.name || 'محمد'} `;
function renderContactDetails(data) {
    document.querySelector('#display-phone').textContent = `التليفون: ${data.phone || 'غير مضاف'}`;
    document.querySelector('#display-guardian').textContent = `ولي الأمر: ${data.guardianPhone || 'غير مضاف'}`;
}

renderContactDetails(user);
document.querySelector('#edit-profile').addEventListener('click', () => {
    document.querySelector('#profile-form').classList.toggle('hidden');
});

document.querySelector('#save-profile').addEventListener('click', () => {
    const updatedUser = { name: document.querySelector('#user-name').value.trim() || 'محمد', phone: document.querySelector('#user-phone').value.trim(), guardianPhone: document.querySelector('#guardian-phone').value.trim() };
    localStorage.setItem('muzakara-user', JSON.stringify(updatedUser));
    document.querySelector('#profile-name').textContent = updatedUser.name;
    document.querySelector('#profile-heading').firstChild.textContent = `أهلاً، ${updatedUser.name} `;
    renderContactDetails(updatedUser);
    document.querySelector('#profile-form').classList.add('hidden');
    document.querySelector('#profile-saved').textContent = 'تم حفظ بياناتك.';
});

document.querySelector('#profile-time').textContent = formatTime(totalSeconds);
document.querySelector('#profile-percent').textContent = `${tasks.length ? Math.round(completed / tasks.length * 100) : 0}%`;
document.querySelector('#profile-tasks').textContent = `${completed} من ${tasks.length} مهام مكتملة`;
document.querySelector('#profile-sessions').textContent = sessions.length;

const dayNames = ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];
const currentDay = new Date().getDay();
const dayTotals = dayNames.map((name, index) => ({ name, seconds: weeklySessions.filter((session) => (session.day ?? currentDay) === index).reduce((total, session) => total + session.seconds, 0) }));
const maxSeconds = Math.max(...dayTotals.map((day) => day.seconds), 60);
document.querySelector('#week-chart').innerHTML = dayTotals.map((day) => `<div class="chart-column"><div class="chart-value" style="height:${Math.max(8, day.seconds / maxSeconds * 100)}%"></div><span>${day.name}</span></div>`).join('');

document.querySelector('#profile-subjects').innerHTML = subjectsData.length ? subjectsData.map((subject) => {
    const percent = subject.target ? Math.min(100, Math.round(subject.studied / subject.target * 100)) : 0;
    return `<a class="profile-subject" href="./subject.html?name=${encodeURIComponent(subject.name)}"><strong>${escapeHtml(subject.name)}</strong><span>${percent}%</span><div class="subject-bar"><i style="width:${percent}%;background:${subject.color}"></i></div></a>`;
}).join('') : '<p class="empty-state">أضف موادك من الصفحة الرئيسية.</p>';

document.querySelector('#theme-toggle').addEventListener('click', () => {
    window.toggleTheme();
    document.querySelector('#theme-toggle span').textContent = document.body.classList.contains('dark-mode') ? 'الوضع النهاري' : 'الوضع الليلي';
});