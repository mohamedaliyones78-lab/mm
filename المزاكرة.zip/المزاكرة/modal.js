const modal = document.createElement('div');
modal.className = 'site-modal';
modal.innerHTML = `<div class="site-modal-box"><h2 id="modal-title"></h2><p id="modal-message"></p><input id="modal-input" type="text"><div class="site-modal-actions"><button id="modal-cancel" type="button">إلغاء</button><button id="modal-ok" type="button">تأكيد</button></div></div>`;
document.body.appendChild(modal);

const modalTitle = modal.querySelector('#modal-title');
const modalMessage = modal.querySelector('#modal-message');
const modalInput = modal.querySelector('#modal-input');
const modalCancel = modal.querySelector('#modal-cancel');
const modalOk = modal.querySelector('#modal-ok');
let closeModal = null;

function showModal({ title, message = '', input = false, confirmText = 'تأكيد' }) {
    modalTitle.textContent = title;
    modalMessage.textContent = message;
    modalInput.value = '';
    modalInput.hidden = !input;
    modalOk.textContent = confirmText;
    modal.classList.add('open');
    if (input) window.setTimeout(() => modalInput.focus(), 0);
    return new Promise((resolve) => {
        closeModal = (value) => {
            modal.classList.remove('open');
            closeModal = null;
            resolve(value);
        };
    });
}

modalCancel.addEventListener('click', () => closeModal?.(null));
modalOk.addEventListener('click', () => closeModal?.(modalInput.hidden ? true : modalInput.value.trim()));
modalInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') modalOk.click();
});
modal.addEventListener('click', (event) => {
    if (event.target === modal) closeModal?.(null);
});

window.openTextModal = (title, message = '') => showModal({ title, message, input: true, confirmText: 'إضافة' });
window.openConfirmModal = (message) => showModal({ title: 'تأكيد العملية', message, confirmText: 'حذف' });
